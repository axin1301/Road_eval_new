import shp2txt
import mapcompare_GE
import average_statistics


shp2txt.main()
mapcompare_GE.main()
average_statistics.main()